OpenVPN 3 is distributed under 
`GNU Affero General Public License version 3 <COPYRIGHT.AGPLV3>`_
with a special permission to link against OpenSSL:

::

    Additional permission under GNU AGPL version 3 section 7
    
    If you modify this Program, or any covered work, by linking or combining
    it with OpenSSL (or a modified version of that library), containing parts
    covered by the terms of the OpenSSL License or the Original SSLeay License,
    the licensors of this Program grant you additional permission to convey the
    resulting work. Corresponding Source for a non-source form of such a
    combination shall include the source code for the parts of OpenSSL used as
    well as that of the covered work.
